Cached data from GitHub API.
